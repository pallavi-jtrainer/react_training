package com.springpeople.boot.rest.TutorialsBackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TutorialsBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
