package com.springpeople.boot.rest.TutorialsBackend.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springpeople.boot.rest.TutorialsBackend.entity.Users;
import com.springpeople.boot.rest.TutorialsBackend.exceptions.ResourceNotFoundException;
import com.springpeople.boot.rest.TutorialsBackend.repository.UsersRepository;

@Service
public class UsersService {
	
	@Autowired
	private UsersRepository repo;
	
	public Users retrieveUserDetailsByUsername(String name) 
			throws ResourceNotFoundException {
		Users user = repo.findByUsername(name);
		if(user == null) {
			throw new ResourceNotFoundException("User with username: " + name + " not found");
		}
		
		return user;
	}
	
	public Users getUserById(long id) throws ResourceNotFoundException {
		Users user = repo.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("User with id: " + id + " not found" ));
		return user;
	}
	
	public Users retrieveUserDetailsByEmail(String email) 
			throws ResourceNotFoundException {
		Users user = repo.findByEmail(email);
		if(user == null) {
			throw new ResourceNotFoundException("User with email: " + email + " not found");
		}
		
		return user;
	}
	
	public Users createUser(Users user) {
		return repo.save(user);
	}
	
	public String updatePassword(long id, String pass) throws ResourceNotFoundException {
		String str = "Unable to update password";
		
		@SuppressWarnings("unused")
		Users user = repo.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("User with id: " + id + " not found" ));
		
		int res = repo.updatePassword(id, pass);
		if (res > 0) {
			str = "Password updated";
		}
		
		return str;
		
	}
}
