package com.springpeople.boot.rest.TutorialsBackend.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springpeople.boot.rest.TutorialsBackend.entity.Tutorials;
import com.springpeople.boot.rest.TutorialsBackend.exceptions.ResourceNotFoundException;
import com.springpeople.boot.rest.TutorialsBackend.repository.TutorialsRepository;

@Service
public class TutorialsService {
	
	@Autowired
	private TutorialsRepository repo;
	
	public List<Tutorials> listAllTutorials() {
		return repo.findAll();
	}
	
	public List<Tutorials> listAllByCategory(String cat) {
		return repo.findAllByCategory(cat);
	}
	
	public List<Tutorials> listAllByPrice(double min, double max) {
		return repo.findAllByPriceBetween(min, max);
	}
	
	public Tutorials retrieveTutorialDetails(long id) throws ResourceNotFoundException {
		Tutorials tutorial = repo.findById(id)
				.orElseThrow(()-> new ResourceNotFoundException("Tutorial with id: " + id + " not found"));
		
//		if (tutorial == null) {
//			throw new ResourceNotFoundException("Tutorial with id: " + id + " not found");
//		}
		
//				.orElseThrow(()-> new ResourceNotFoundException("Tutorial with id: " + id + " not found"));
		return tutorial;
		
	}
	
//	public Tutorials retrieveTutorialDetails(long id) {
//		return repo.findById(id).get();
//	}
	
	public Tutorials createTutorial(Tutorials tutorial) {
		return repo.save(tutorial);
	}
	
	public int updateTutorial(long id, double price) {
		return repo.updatePrice(id, price);
	}
	
	public void deleteTutorial(long id) {
		repo.deleteById(id);
	}
	
}
