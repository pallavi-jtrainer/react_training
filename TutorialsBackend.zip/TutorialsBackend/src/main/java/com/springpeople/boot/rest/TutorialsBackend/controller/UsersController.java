package com.springpeople.boot.rest.TutorialsBackend.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springpeople.boot.rest.TutorialsBackend.entity.Users;
import com.springpeople.boot.rest.TutorialsBackend.exceptions.ResourceNotFoundException;
import com.springpeople.boot.rest.TutorialsBackend.service.UsersService;

import jakarta.transaction.Transactional;

@CrossOrigin("http://localhost:4200")
@RestController
@RequestMapping("/api/users")
public class UsersController {
	
	@Autowired
	private UsersService service;
	
	@GetMapping("/{id}")
	public ResponseEntity<Users> getUserById(@PathVariable long id) throws ResourceNotFoundException {
		Users user = service.getUserById(id);
		return ResponseEntity.ok().body(user);
	}
	
	@GetMapping("/user/{name}")
	public ResponseEntity<Users> getUserByUserName(@PathVariable String name) throws ResourceNotFoundException {
		Users user = service.retrieveUserDetailsByUsername(name);
		return ResponseEntity.ok().body(user);
	}
	
	@GetMapping("/email/{email}")
	public ResponseEntity<Users> getUserByEmail(@PathVariable String email) throws ResourceNotFoundException {
		Users user = service.retrieveUserDetailsByEmail(email);
		return ResponseEntity.ok().body(user);
	}
	
	@PostMapping
	public ResponseEntity<Users> createUser(@RequestBody Users user) {
		Users u = service.createUser(user);
		return ResponseEntity.ok().body(u);
	}
	
	@Transactional
	@PutMapping("/pass/{id}/{pass}")
	public ResponseEntity<String> updatePassword(@PathVariable long id, @PathVariable String pass) throws ResourceNotFoundException {
		String str = service.updatePassword(id, pass);
		return ResponseEntity.ok().body(str);
	}
}
