package com.springpeople.boot.rest.TutorialsBackend.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springpeople.boot.rest.TutorialsBackend.entity.Tutorials;
import com.springpeople.boot.rest.TutorialsBackend.exceptions.ResourceNotFoundException;
import com.springpeople.boot.rest.TutorialsBackend.service.TutorialsService;

import jakarta.transaction.Transactional;

@CrossOrigin("http://localhost:4200")
@RestController
@RequestMapping("/api/tutorials")
public class TutorialsController {

	@Autowired
	private TutorialsService service;
	
	@GetMapping
	public List<Tutorials> listAll() {
		return service.listAllTutorials();
	}
	
	@PostMapping
	public Tutorials createTutorial(@RequestBody Tutorials tutorial) {
		return service.createTutorial(tutorial);
	}
	
	@GetMapping("/price/{min}/{max}")
	public List<Tutorials> listAllByPrice(@PathVariable long min, @PathVariable long max) {
		return service.listAllByPrice(min, max);
	}
	
	@GetMapping("/cat/{cat}")
	public List<Tutorials> listByCategory(@PathVariable String cat) {
		return service.listAllByCategory(cat);
	}
	
//	@GetMapping("/{id}")
//	public Tutorials getTutorialDetails(@PathVariable long id) {
//		Tutorials t = null;
//		try {
//			t = service.retrieveTutorialDetails(id);
//		} catch (ResourceNotFoundException e) {
//			System.out.println(e.getMessage());
//			e.printStackTrace();
//		}
//		
//		return t;
//	}
	
	@GetMapping("/{id}")
	public ResponseEntity<Tutorials> getTutorialDetails(@PathVariable long id) throws ResourceNotFoundException{
		Tutorials t = service.retrieveTutorialDetails(id);
		return ResponseEntity.ok().body(t);
	}
	
//	@Transactional
//	@PutMapping("/update/{id}/{price}")
//	public ResponseEntity<String> updateTutorialPrice(@PathVariable long id, @PathVariable double price) {
//		String str = "Unable to update tutorial";
//		
//		int res = service.updateTutorial(id, price);
//		if(res > 0) {
//			str = "Tutorial price updated successfully";
//		}
//		
//		return ResponseEntity.ok().body(str);
//	}
	
	@Transactional
	@PutMapping("/update/{id}/{price}")
	public ResponseEntity<Tutorials> updateTutorialPrice(@PathVariable long id, @PathVariable double price) 
			throws ResourceNotFoundException{
		Tutorials t = null;
		
		int res = service.updateTutorial(id, price);
		if(res > 0) {
			//str = "Tutorial price updated successfully";
			t = service.retrieveTutorialDetails(id);
		}
		
		return ResponseEntity.ok().body(t);
	}
	
	@DeleteMapping("/delete/{id}")
	public void deleteTutorial(@PathVariable long id) throws ResourceNotFoundException {
		service.deleteTutorial(id);
	} 
}
