package com.springpeople.boot.rest.TutorialsBackend.entity;

import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="tutorials")
public class Tutorials {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	
	@Column(name="tutorialname")
	private String tutorialName;
	
	@Column(name="price")
	private double price;
	
	@Column(name="category")
	private String category;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getTutorialName() {
		return tutorialName;
	}

	public void setTutorialName(String tutorialName) {
		this.tutorialName = tutorialName;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	@Override
	public int hashCode() {
		return Objects.hash(category, id, price, tutorialName);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Tutorials other = (Tutorials) obj;
		return Objects.equals(category, other.category) && id == other.id
				&& Double.doubleToLongBits(price) == Double.doubleToLongBits(other.price)
				&& Objects.equals(tutorialName, other.tutorialName);
	}

	@Override
	public String toString() {
		return "Tutorials [id=" + id + ", tutorialName=" + tutorialName + ", price=" + price + ", category=" + category
				+ "]";
	}
	
	public Tutorials() {
		
	}

//	public Tutorials(long id, String tutorialName, double price, String category) {
//		this.id = id;
//		this.tutorialName = tutorialName;
//		this.price = price;
//		this.category = category;
//	}

	public Tutorials(String tutorialName, double price, String category) {
		this.tutorialName = tutorialName;
		this.price = price;
		this.category = category;
	}
}
