package com.springpeople.boot.rest.TutorialsBackend.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.springpeople.boot.rest.TutorialsBackend.entity.Tutorials;

@Repository
public interface TutorialsRepository extends JpaRepository<Tutorials, Long>{
	
	public List<Tutorials> findAllByCategory(String category);
	public List<Tutorials> findAllByPriceBetween(double min, double max);
	
	@Modifying
	@Query("update Tutorials t set t.price = :newPrice where t.id = :id")
	public int updatePrice(@Param("id") long id, @Param("newPrice") double newPrice);
}
