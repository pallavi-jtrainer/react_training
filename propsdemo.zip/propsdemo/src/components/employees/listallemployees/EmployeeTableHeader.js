import React, { Component } from "react";

export default class EmployeeTableHeader
     extends Component {
    render() {
        return(
            <thead>
                <tr>
                    <th>Employee Name</th>
                    <th>Employee Role</th>
                </tr>
            </thead>
        );
    }
}