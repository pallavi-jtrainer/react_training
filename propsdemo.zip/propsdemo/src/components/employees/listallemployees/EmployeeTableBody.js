// import React, {Component} from "react";

// export default class EmployeeTableBody extends Component {
//     // eslint-disable-next-line no-useless-constructor
//     constructor(props) {
//         super(props);
//     }

//     render() {
//         let employeeData = this.props;
//         console.log(employeeData);
//         const numRows = employeeData.map(row => {
//             return(
//                 <tr>
//                     <td>{row.name}</td>
//                     <td>{row.role}</td>
//                 </tr>
//             );
//         });
        
//         return(
//             <tbody>{numRows}</tbody>
//         );
//     }
// }

import React from "react";

export default function EmployeeTableBody(props) {
    //  console.log(props.employeeData);
    // const { arr } = props;
    return(
        <tbody>
            {props.employeeData.map(data => {
                return(
                    <tr>
                        <td>{data.name}</td>
                        <td>{data.role}</td>
                    </tr>
                )
            })}
        </tbody>
    );
}