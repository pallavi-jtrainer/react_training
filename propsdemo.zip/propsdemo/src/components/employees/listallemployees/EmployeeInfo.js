// import React, {Component} from 'react';
// import EmployeeTable from './EmployeeTable';

import EmployeeTable from "./EmployeeTable";

// export default class EmployeeInfo extends Component {
//     render() {

//         let employeeData = [
//             {"name": "Tony Stark", "role": "QA Engineer"},
//             {"name": "Clark Kent", "role": "Software Developer"},
//             {"name": "Bruce Wayne", "role": "Software Developer"}
//         ];

//         return(
//             <div>
//                 <EmployeeTable employeeData = {employeeData}/>
//             </div>
//         );
//     }
// }
import React from "react";

let employeeData = [
    {"name": "Tony Stark", "role": "QA Engineer"},
    {"name": "Clark Kent", "role": "Software Developer"},
    {"name": "Bruce Wayne", "role": "Software Developer"}
];

export default function EmployeeInfo() {
    return (
        <div>
            <EmployeeTable employeeData = {employeeData} />
        </div>
    );
}