// import React, {Component} from "react";
// import EmployeeTableHeader from "./EmployeeTableHeader";
// import EmployeeTableBody from "./EmployeeTableBody";

import EmployeeTableBody from "./EmployeeTableBody";
import EmployeeTableHeader from "./EmployeeTableHeader";

// export default class EmployeeTable extends Component {
//     render() {
//         // let employeeData = [];
//         // employeeData = this.props;
//         const { employeeData } = this.props;
//         console.log(employeeData);
//         return(
//             <div>
//                 <table>
//                     <EmployeeTableHeader />
//                     {/* <EmployeeTableBody employeeData={employeeData}/> */}
//                 </table>
//             </div>
//         );
//     }
// }

import React from "react";

export default function EmployeeTable(props) {
    const { employeeData } = props;

    return (
        <div>
            <table>
                <EmployeeTableHeader/>
                <EmployeeTableBody employeeData = {employeeData}/>
            </table>
        </div>
    );
}