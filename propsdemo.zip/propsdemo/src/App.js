//import logo from './logo.svg';
import './App.css';
import EmployeeTable from './components/employees/listallemployees/EmployeeTable';

let employeeData = [
  {"name": "Tony Stark", "role": "QA Engineer"},
  {"name": "Clark Kent", "role": "Software Developer"},
  {"name": "Bruce Wayne", "role": "Software Developer"}
];

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <EmployeeTable employeeData = {employeeData}/>
      </header>
    </div>
  );
}

export default App;
